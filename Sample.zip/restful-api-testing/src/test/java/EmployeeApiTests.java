import java.util.Random;

import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

public class EmployeeApiTests {

	String baseURI = "http://localhost:8080/demo/employee";
	String id;
    int statusCode;
    
    @Test
    public void employeeTest() {
    	getAllEmployees();
    	createEmployeeTest();
    	updateUserDetailsTest();
    	getEmployee();
    	deleteEmployeeTest();
    	getAllEmployees();
    }

    //@Test
    public void getAllEmployees() {
        RestAssured.baseURI = baseURI;

        Response  response = given().get("/getAll");
        
        System.out.println("Available list of employess");
        System.out.println(response.getBody().asString());

        statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200);

    }

    //@Test
    public void createEmployeeTest() {
        RestAssured.baseURI = baseURI;

        RequestSpecification httpRequest = RestAssured.given();

        JSONObject requestParams = new JSONObject();
        id = String.valueOf(new Random().nextInt());
        requestParams.put("id", id);
        requestParams.put("name", "Srini");
        

        httpRequest.header("Content-Type", "application/json");

        //httpRequest.body(requestParams.toString());
        
        httpRequest.body(new Employee(id, "Srini"));

        Response response = httpRequest.post("/add");

        statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 201);
        
        System.out.println("Employee created successfully");
        System.out.println(response.getBody().asString());
        

    }

    //@Test
    public void updateUserDetailsTest() {

        RestAssured.baseURI = baseURI;

        RequestSpecification httpRequest = RestAssured.given();

        JSONObject updateData = new JSONObject();
        updateData.put("id", id);
        updateData.put("name", "Jy");

        httpRequest.header("Content-Type", "application/json");

        httpRequest.body(updateData.toJSONString());
        Response response = httpRequest.request(Method.PUT, "/update/"+id);
        statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200);

        JsonPath newData = response.jsonPath();
        String name = newData.get("name");
        Assert.assertEquals(name, "Jy");
        
        System.out.println("Employee Updated successfully");
        System.out.println(response.getBody().asString());

    }
    
    //@Test
    public void getEmployee() {
        RestAssured.baseURI = baseURI;

        RequestSpecification httpRequest = RestAssured.given();

        Response response = httpRequest.request(Method.GET, "/get/" + id);

        String responseBody = response.getBody().asString();
        
        

        statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200);
        
        System.out.println("Employee Retrieved successfully");
        System.out.println(responseBody);

    }


    //@Test
    public void deleteEmployeeTest() {
        RestAssured.baseURI = baseURI;

        RequestSpecification httpRequest = RestAssured.given();

        Response response = httpRequest.request(Method.DELETE, "/delete/"+ id);
        statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200);
        
        System.out.println("Employee deleted successfully");
    }
    
    /*
	 * @Test void checkAuthorizationTest() {
	 * 
	 * RestAssured.baseURI = "https://postman-echo.com/basic-auth";
	 * 
	 * RequestSpecification httpRequest = RestAssured.given();
	 * 
	 * Response response = httpRequest.request(Method.GET, "/");
	 * 
	 * statusCode = response.getStatusCode(); Assert.assertEquals(statusCode, 401);
	 * 
	 * httpRequest.auth().preemptive().basic("postman", "password");
	 * 
	 * Response responseWithAuth = httpRequest.request(Method.GET, "/"); statusCode
	 * = responseWithAuth.getStatusCode(); Assert.assertEquals(statusCode, 200);
	 * 
	 * JsonPath respeone = responseWithAuth.jsonPath();
	 * 
	 * Boolean authentication = respeone.get("authenticated");
	 * Assert.assertTrue(authentication); }
	 */

}
